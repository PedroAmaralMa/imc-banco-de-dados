package br.gov.sp.cps.imc_banco;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "imc.db";

    public static final String TABLE_NAME = "usuarios";

    public static final String COL_1 = "ID";

    public static final String COL_2 = "NOME";

    public static final String COL_3 = "IDADE";

    public static final String COL_4 = "PESO";

    public static final String COL_5 = "ALTURA";

    public static final String COL_6 = "IMC";

    public static final String COL_7 = "CLASSIFICACAO";

    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " " +
                "(ID INTEGER PRIMARY KEY AUTOINCREMENT, NOME TEXT NOT NULL, IDADE INTEGER NOT NULL, PESO REAL NOT NULL, ALTURA REAL NOT NULL, IMC REAL NOT NULL, CLASSIFICACAO TEXT NOT NULL)");
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean inserir(String nome, int idade, double peso, double altura, double imc, String classificacao){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(COL_2, nome);
        contentValues.put(COL_3, idade);
        contentValues.put(COL_4, peso);
        contentValues.put(COL_5, altura);
        contentValues.put(COL_6, imc);
        contentValues.put(COL_7, classificacao);

        long resultado = db.insert(TABLE_NAME, null, contentValues);

        db.close();

        return resultado != 1;
    }

    public Cursor obterPorNome(String nome){
        SQLiteDatabase db = this.getReadableDatabase();

        String[] colunas = {COL_2, COL_3, COL_4, COL_5, COL_6, COL_7};

        String selecao = COL_2 + " = ?";

        String[] argumentosSelecao = {nome};

        return db.query(
                TABLE_NAME,
                colunas,
                selecao,
                argumentosSelecao,
                null,
                null,
                null);
    }

    public boolean atualizar(String nome, int novaIdade, double novoPeso, double novaAltura, double novoImc, String novaClassificacao){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(COL_3, novaIdade);
        contentValues.put(COL_4, novoPeso);
        contentValues.put(COL_5, novaAltura);
        contentValues.put(COL_6, novoImc);
        contentValues.put(COL_7, novaClassificacao);

        int linhasAfetadas = db.update(
                TABLE_NAME,
                contentValues,
                COL_2 + " = ?",
                new String[] {nome}
        );

        db.close();

        return linhasAfetadas > 0;


    }

    public boolean deletar(String nome){
        SQLiteDatabase db = this.getWritableDatabase();

        int linhasAfetadas = db.delete(
                TABLE_NAME,
                COL_2 + " = ?",
                new String[] {nome}
        );

        db.close();

        return linhasAfetadas > 0;
    }
}
