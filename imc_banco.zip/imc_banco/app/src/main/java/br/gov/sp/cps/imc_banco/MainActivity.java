package br.gov.sp.cps.imc_banco;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    private TextInputEditText txtNome, txtIdade, txtPeso, txtAltura;
    private Button btnGravar, btnConsultar, btnAtualizar, btnDeletar;

    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        inicializarComponentes();

        db = new DatabaseHelper(this);

        btnGravar.setOnClickListener(view -> {
            String nome = txtNome.getText().toString();
            String idade = txtIdade.getText().toString();
            String peso = txtPeso.getText().toString();
            String altura = txtAltura.getText().toString();

            if (temErro(nome, idade, peso, altura)){
                return;
            }

            try {
                int valorIdade = Integer.parseInt(idade);

                double valorPeso = Double.parseDouble(peso);
                double valorAltura = Double.parseDouble(altura);
                double valorImc = calcularImc(valorPeso, valorAltura);

                String classificacao = classificar(valorImc);

                

                if (db.inserir(nome, valorIdade, valorPeso, valorAltura, valorImc, classificacao)) {
                    Intent intent = new Intent(this, ResultadoImcActivity.class);
                    intent.putExtra("nome", nome);
                    intent.putExtra("idade", idade);
                    intent.putExtra("peso", String.format("%.2f", valorPeso));
                    intent.putExtra("altura", String.format("%.2f", valorAltura));
                    intent.putExtra("imc", String.format("%.2f", valorImc));
                    intent.putExtra("classificacao", classificacao);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Erro ao Inserir", Toast.LENGTH_LONG).show();
                }
            } catch (NumberFormatException e){
                Toast.makeText(this, "Erro ao Inserir", Toast.LENGTH_LONG).show();
            }






        });

        btnConsultar.setOnClickListener(view -> {
            String nome = txtNome.getText().toString();
            if (nome.trim().isEmpty()) {
                txtNome.setError("Insira seu nome");
                return;
            }
            txtNome.setError(null);

            Cursor cursor = db.obterPorNome(nome);
            if (cursor != null && cursor.moveToFirst()){
                int idade = cursor.getInt(cursor.getColumnIndexOrThrow("IDADE"));
                double peso = cursor.getDouble(cursor.getColumnIndexOrThrow("PESO"));
                double altura = cursor.getDouble(cursor.getColumnIndexOrThrow("ALTURA"));
                double imc = cursor.getDouble(cursor.getColumnIndexOrThrow("IMC"));
                String classificacao = cursor.getString(cursor.getColumnIndexOrThrow("CLASSIFICACAO"));
                Intent intent = new Intent(this, ResultadoImcActivity.class);
                intent.putExtra("nome", nome);
                intent.putExtra("idade", Integer.toString(idade));
                intent.putExtra("peso", String.format("%.2f", peso));
                intent.putExtra("altura", String.format("%.2f", altura));
                intent.putExtra("imc", String.format("%.2f", imc));
                intent.putExtra("classificacao", classificacao);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Nome não encontrado", Toast.LENGTH_LONG).show();
            }
            });

        btnAtualizar.setOnClickListener(view -> {
            String nome = txtNome.getText().toString();
            String idade = txtIdade.getText().toString();
            String peso = txtPeso.getText().toString();
            String altura = txtAltura.getText().toString();

            if (temErro(nome, idade, peso, altura)){
                return;
            }

            try {
                int valorIdade = Integer.parseInt(idade);

                double valorPeso = Double.parseDouble(peso);
                double valorAltura = Double.parseDouble(altura);
                double valorImc = calcularImc(valorPeso, valorAltura);

                String classificacao = classificar(valorImc);

                if (db.atualizar(nome, valorIdade, valorPeso, valorAltura, valorImc, classificacao)) {
                    Intent intent = new Intent(this, ResultadoImcActivity.class);
                    intent.putExtra("nome", nome);
                    intent.putExtra("idade", idade);
                    intent.putExtra("peso", String.format("%.2f", valorPeso));
                    intent.putExtra("altura", String.format("%.2f", valorAltura));
                    intent.putExtra("imc", String.format("%.2f", valorImc));
                    intent.putExtra("classificacao", classificacao);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Nome não encontrado", Toast.LENGTH_LONG).show();
                }
            } catch (NumberFormatException e){
                Toast.makeText(this, "Erro ao Atualizar", Toast.LENGTH_LONG).show();
            }

        });



        btnDeletar.setOnClickListener(view -> {
            String nome = txtNome.getText().toString();
            if (nome.trim().isEmpty()){
                txtNome.setError("Insira seu nome");
                return;
            }
            txtNome.setError(null);

            if (db.deletar(nome)){
                Toast.makeText(this, "Usuário deletado com sucesso", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Nome não encontrado", Toast.LENGTH_LONG).show();
            }
            });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void inicializarComponentes(){
        txtNome       = findViewById(R.id.editTextNome);
        txtIdade      = findViewById(R.id.editTextIdade);
        txtPeso       = findViewById(R.id.editTextPeso);
        txtAltura     = findViewById(R.id.editTextAltura);

        btnGravar     = findViewById(R.id.btnGravar);
        btnConsultar  = findViewById(R.id.btnConsultar);
        btnAtualizar  = findViewById(R.id.btnAtualizar);
        btnDeletar    = findViewById(R.id.btnDeletar);
    }

    public boolean temErro(String nome, String idade, String peso, String altura){
        boolean erro = false;
        if (nome.trim().isEmpty()){
            txtNome.setError("Insira seu nome");
            erro = true;
        }
        else {
            txtNome.setError(null);
        }

        if (idade.trim().isEmpty()){
            txtIdade.setError("Insira sua idade");
            erro = true;
        }
        else {
            txtIdade.setError(null);
        }

        if (peso.trim().isEmpty()){
            txtPeso.setError("Insira seu peso");
            erro = true;
        }

        else {
            txtPeso.setError(null);
        }

        if (altura.trim().isEmpty()){
            txtAltura.setError("Insira sua altura");
            erro = true;
        }

        else {
            txtAltura.setError(null);
        }

        return erro;
    }

    public double calcularImc(double peso, double altura){
        return peso / (altura * altura);
    }

    public String classificar(double imc) {
        if (imc > 0 && imc < 18.5) {
            return "Abaixo do Peso";
        } else if (imc >= 18.5 && imc < 25.0) {
            return "Peso Normal";
        } else if (imc >= 25.0 && imc < 30.0) {
            return "Sobrepeso";
        } else if (imc >= 30.0 && imc < 35.0) {
            return "Obesidade Grau I";
        } else if (imc >= 35.0 && imc < 40.0) {
            return "Obesidade Grau II";
        } else {
            return "Obesidade Grau III";
        }
    }
}