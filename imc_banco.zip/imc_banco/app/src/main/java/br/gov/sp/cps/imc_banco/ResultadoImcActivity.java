package br.gov.sp.cps.imc_banco;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResultadoImcActivity extends AppCompatActivity {
    private TextView txtValores, txtMensagem;

    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.resultado_imc);

        txtValores = findViewById(R.id.txtValores);
        txtMensagem = findViewById(R.id.txtMensagem);

        btnVoltar = findViewById(R.id.btnVoltar);

        Intent intent = getIntent();

        String nome = intent.getStringExtra("nome");
        String idade = intent.getStringExtra("idade");
        String peso = intent.getStringExtra("peso");
        String altura = intent.getStringExtra("altura");
        String imc = intent.getStringExtra("imc");
        String classificacao = intent.getStringExtra("classificacao");

        txtValores.setText("Nome: " + nome + "\n" + "Idade: " + idade + "\n" + "Peso: " + peso + "\n" + "Altura: " + altura + "\n" + "IMC: " + imc + "\n" + "Classificação: " + classificacao + "\n");
        txtMensagem.setText(exibirMensagem(classificacao));

        btnVoltar.setOnClickListener(view -> {
            finish();
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private String exibirMensagem(String classificacao) {
        if (classificacao.equals("Abaixo do Peso")) {
            return "Você está abaixo do peso ideal, procure um médico.";
        }
        else if (classificacao.equals("Peso Normal")) {
            return "Você está no peso ideal.";
        }
        else if (classificacao.equals("Sobrepeso")) {
            return "Você está com sobrepeso, avalie procurar assistência médica.";
        }
        else if (classificacao.equals("Obesidade Grau I")) {
            return "Você está com obesidade Grau I, procure um médico, situação de risco.";
        }
        else if (classificacao.equals("Obesidade Grau II")) {
            return "Você está com obesidade Grau II, procure um médico, situação de grave.";
        }
        else {
            return "Você está com obesidade Grau III, procure um médico, situação de risco de morte.";
        }
    }
}